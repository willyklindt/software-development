public class RoRo extends Vessel {
    double carLength;
    double truckLength;
    double fraction;

    public boolean checkCargo() {
        return carLength + truckLength > cargo;
    }

    public boolean checkFraction() {
        return utilitylevelofCapacity() < 100.0;
    }

    public boolean belowBoundary() {
        return utilitylevelofCapacity() < 0;
    }

    public RoRo(String flagNation, int draft, int length, int width, int cargo) {
        super(flagNation, draft, length, width, cargo);

    }

    public void loadingCargo(int vehicles, int trucks) {
        this.carLength = vehicles * 8;
        this.truckLength = trucks * 30;
    }

    public double utilitylevelofCapacity() {
        this.fraction = ((this.carLength + this.truckLength) / cargo) * 100.0;
        return fraction;
    }
}