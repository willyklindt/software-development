public class freightDepartment {

    public double searchNearestShip(double shipPosition) { // Locate the nearest ship.
        return shipPosition;
    }

    public static boolean testCatchShip() { // Unit test that checks if the vessel it finds, is the closest vessel.
        return true;
    }

    public String changeDestination(String changedDestination) { // Changes destination of ship.
        return changedDestination;
    }

    public static boolean testChange() { // Unit test that checks if the vessels destination has been changed.
        return true;
    }

}
