public class Main {
    public static void main(String[] args) {
        Tankers tankersVessel = new Tankers("Norge", 25, 100, 40, 10);
        Container containerVessel = new Container("Somalia", 1, 5, 2, 25);
        RoRo roRoVessel = new RoRo("Finland", 50, 150, 60, 150);

        tankersVessel.loadingCargo(10);
        tankersVessel.utilitylevelofCapacity();
        containerVessel.loadingCargo(26);
        containerVessel.utilitylevelofCapacity();
        roRoVessel.loadingCargo(7, 1);
        roRoVessel.utilitylevelofCapacity();

    }

}
