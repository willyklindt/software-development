public class Tankers extends Vessel {
    double compartmentsAmount;
    double fraction;

    public boolean checkCargo() {
        return compartmentsAmount > cargo;
    }

    public boolean checkFraction() {
        return utilitylevelofCapacity() < 100.0;
    }

    public boolean belowBoundary() {
        return utilitylevelofCapacity() < 0;
    }

    public Tankers(String flagNation, int draft, int length, int width, int cargo) {
        super(flagNation, draft, length, width, cargo);

    }

    public void loadingCargo(int compartments) {
        compartmentsAmount = compartments;
    }

    public double utilitylevelofCapacity() {
        this.fraction = (this.compartmentsAmount / cargo) * 100.0;
        return fraction;
    }

}
