public abstract class Vessel {
    
        String flagNation;
        int draft;
        int length;
        int width;
        double cargo;
    
        public Vessel(String flagNation, int draft, int length, int width, int cargo) {
            this.flagNation = flagNation;
            this.draft = draft;
            this.length = length;
            this.width = width;
            this.cargo = cargo;
    
        }
    
        abstract boolean checkCargo();
    
        abstract double utilitylevelofCapacity();
    
        abstract boolean checkFraction();
    
        abstract boolean belowBoundary();
    
}
