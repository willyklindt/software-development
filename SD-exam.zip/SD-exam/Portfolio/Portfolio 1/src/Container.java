public class Container extends Vessel {
    double containerAmount;
    double fraction;

    public boolean checkCargo() { // Hvis antallet af containers er større end max, returner true
        return containerAmount > cargo;
    }

    public double utilitylevelofCapacity() {
        this.fraction = (this.containerAmount / cargo) * 100.0;
        return fraction;
    }

    public boolean checkFraction() {
        return utilitylevelofCapacity() < 100.0;
    }

    public boolean belowBoundary() {
        return utilitylevelofCapacity() < 0;
    }

    public Container(String flagNation, int draft, int length, int width, int cargo) {
        super(flagNation, draft, length, width, cargo);

    }

    public void loadingCargo(int containers) {
        this.containerAmount = containers;
    }

}
